package patient;

/**
 * 
 * Management of appointments .. Work in progress.
 */
public class AppointmentService {

	public void add(Appointment appointment) {
		;
		
	}

	public Appointment[] getAppointments() {
		return null;
	}

}
